import React from 'react';
import logo from './logo.svg';
import './App.css';
import Container from './components/container/Container';

function App() {
  return (
    <Container/>
  );
}

export default App;
